import sqlite3
conn = sqlite3.connect('messages.db')

# Создание курсора
cursor = conn.cursor()

# Создание таблицы
cursor.execute('''
    CREATE TABLE IF NOT EXISTS messages (
        message TEXT NOT NULL,
        from TEXT NOT NULL,
        to TEXT NOT NULL
    )
''')

# Сохранение изменений и закрытие
conn.commit()
conn.close()