import socket

while True:
    def start_server():
        host = '0.0.0.0'  # Слушать на всех интерфейсах
        port = 12345

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((host, port))
            s.listen()
            print(f"Сервер слушает {host}:{port}...")
            conn, addr = s.accept()
            with conn:
                print(f"Подключено: {addr}")
                while True:
                    data = conn.recv(1024)
                    if not data: break
                    print(f"Получено: {data.decode('utf-8')}")
        return data.decode('utf-8')


    s = start_server()
    start_server()
    if s == '':
        break