import socket
import threading

PORT = 12345

def start_server(callback):
    def server():
        host = '0.0.0.0'
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((host, PORT))
            s.listen()

            while True:
                conn, addr = s.accept()
                with conn:
                    data = conn.recv(1024)
                    if data:
                        callback(data.decode())

    thread = threading.Thread(target=server, daemon=True)
    thread.start()


def send_message(ip, message):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((ip, PORT))
        s.sendall(message.encode())