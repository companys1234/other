from db import get_connection
import local_ip

def register_user(login, password):
    conn = get_connection('users.db')
    cursor = conn.cursor()

    cursor.execute("SELECT 1 FROM users WHERE login=?", (login,))
    if cursor.fetchone():
        return False, "Логин уже существует"

    ip = local_ip.get_local_ip()

    cursor.execute(
        "INSERT INTO users (login, ip, password) VALUES (?, ?, ?)",
        (login, ip, password)
    )

    conn.commit()
    conn.close()

    return True, "Успешная регистрация"