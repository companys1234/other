import socket

def get_local_ip():
    # Создаем временное соединение для определения IP
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # Адрес не обязательно должен существовать
        s.connect(('8.8.8.8', 1))
        ip = s.getsockname()[0]
    except Exception:
        ip = '127.0.0.1'
    finally:
        s.close()
    return ip

#print("Локальный IP:", get_local_ip())