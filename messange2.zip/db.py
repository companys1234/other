import sqlite3

def get_connection(db_name):
    return sqlite3.connect(db_name)

def init_users():
    conn = get_connection('users.db')
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        ip TEXT,
        login TEXT UNIQUE,
        password TEXT
    )
    """)

    conn.commit()
    conn.close()


def init_messages():
    conn = get_connection('messages.db')
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY,
        message TEXT,
        sender TEXT,
        receiver TEXT
    )
    """)

    conn.commit()
    conn.close()