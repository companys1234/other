import sqlite3

cursor = conn.cursor()

# Получаем все строки из таблицы
cursor.execute("SELECT * FROM users")
rows = cursor.fetchall()

for row in rows:
    print(row)