import sqlite3
import local_ip
def register():
    while True:
        login = str(input('введите логин:'))
        password = str(input('введите пароль:'))
        conn = sqlite3.connect('users.db')
        table_use = 'users'
        column = 'login'
        column2 = 'password'
        cursor = conn.cursor()
        cursor.execute(f'SELECT 1 FROM {table_use} WHERE {column} = ? LIMIT 1', (login,))
        exist = cursor.fetchone()
        if exist:
            print('ошибка: такой логин существует')
            pass
        else:
            #sql = 'INSERT INTO users () VALUES (?,?)'
            ash = local_ip.get_local_ip()
            data = (login, ash)
            #cursor.execute(sql, data)
            #conn.commit()
        cursor.execute(f'SELECT 1 FROM {table_use} WHERE {column2} = ? LIMIT 1', (password,))
        exist = cursor.fetchone()
        if exist:
            print('ошибка: такой пароль уже есть')
            pass
        else:
            sql = 'INSERT INTO users (login,ip,password) VALUES (?,?,?)'
            data = (login, ash, password)
            cursor.execute(sql, data)
            conn.commit()
            print('успешная регистрация')
            conn.close()
            break
            root.destroy()
