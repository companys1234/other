from db import get_connection
import local_ip

def save_message(message, to_ip):
    conn = get_connection('messages.db')
    cursor = conn.cursor()

    sender = local_ip.get_local_ip()

    cursor.execute(
        "INSERT INTO messages (message, from, to) VALUES (?, ?, ?)",
        (message, sender, to_ip)
    )

    conn.commit()
    conn.close()