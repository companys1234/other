import sqlite3

# Подключение к БД (создается файл database.db)
conn = sqlite3.connect('database.db')
cursor = conn.cursor()

# Создание таблицы
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        UID INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        IP TEXT UNIQUE NOT NULL
    )
''')

# Сохраняем изменения и закрываем соединение
conn.commit()
conn.close()