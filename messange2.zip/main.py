import tkinter as tk
from auth import register_user
from network import start_server, send_message
from chat import save_message
import socket

def is_valid_ip(ip):
    try:
        socket.inet_aton(ip)
        return True
    except:
        return False
def on_register():
    login = login_entry.get()
    password = password_entry.get()

    success, msg = register_user(login, password)
    status_label.config(text=msg)

def on_send():
    ip = ip_entry.get().strip()
    message = message_entry.get().strip()

    if not ip or not message:
        status_label.config(text="Введите IP и сообщение")
        return

    if not is_valid_ip(ip):
        status_label.config(text="Неверный IP")
        return

    try:
        send_message(ip, message)
        save_message(message, ip)
        chat_box.insert(tk.END, f"Ты: {message}\n")
    except Exception as e:
        status_label.config(text=f"Ошибка: {e}")

def on_receive(message):
    chat_box.insert(tk.END, f"Друг: {message}\n")

# GUI
root = tk.Tk()
root.title("Messenger")

login_entry = tk.Entry(root)
login_entry.pack()

password_entry = tk.Entry(root)
password_entry.pack()

tk.Button(root, text="Register", command=on_register).pack()

status_label = tk.Label(root, text="")
status_label.pack()

ip_entry = tk.Entry(root)
ip_entry.pack()

message_entry = tk.Entry(root)
message_entry.pack()

tk.Button(root, text="Send", command=on_send).pack()

chat_box = tk.Text(root)
chat_box.pack()

# запуск сервера
start_server(on_receive)

root.mainloop()