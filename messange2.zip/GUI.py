import tkinter as tk
from tkinter import ttk

def on_click():
    label.config(text="Кнопка нажата!")
    
root = tk.Tk() # Создание окна
root.title("Пример")
root.geometry("300x200")

label = ttk.Label(root, text="Привет, Tkinter!") # Создание виджета
label.pack()

btn = tk.Button(root, text="Нажми меня", command=on_click)
btn.pack(pady=20)

root.mainloop()