import requests

def get_public_ip():
    try:
        # Запрос к сервису, возвращающему IP
        response = requests.get('https://api.ipify.org')
        return response.text
    except Exception as e:
        return str(e)

print("Внешний IP:", get_public_ip())