import socket
import local_ip
import sqlite3
conn = sqlite3.connect('messages.db')
cursor = conn.cursor()
def send_message(ip, message):
    port = 12345
    sql = 'INSERT INTO messages (message,from,to) VALUES (?,?,?)'
    ash = local_ip.get_local_ip()
    data = (message, ash, ip)
    cursor.execute(sql, data)
    conn.commit()
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((ip, port))
        s.sendall(message.encode('utf-8'))
        print("Сообщение отправлено")


target_ip = '192.168.1.86'  # Укажите IP получателя
send_message(target_ip, "n")