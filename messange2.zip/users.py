import sqlite3

conn = sqlite3.connect('users.db')

# Создание курсора
cursor = conn.cursor()

# Создание таблицы
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        ip TEXT NOT NULL,
        login TEXT NOT NULL,
        password TEXT NOT NULL
    )
''')

# Сохранение изменений и закрытие
conn.commit()
conn.close()